import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact';
import { ContactsService } from '../contacts.service';


@Component({
  selector: 'app-add-contacts',
  templateUrl: './add-contacts.component.html',
  styleUrls: ['./add-contacts.component.css']
})
export class AddContactsComponent implements OnInit {
conn: Contact = new Contact();
data: any;
  constructor(private service : ContactsService) { 
    this.conn.contactName = 'Mom';
    this.conn.contactNumber="252220";
  }

  ngOnInit(): void {
  }
  getAllContacts(){
    this.service.getContacts().subscribe(data =>{
      this.data=data;
  })
  }
  addContacts(){
    this.service.addContact(this.conn).subscribe(data =>{ 
      this.data= data;
      if(data != null) {
        alert("Added Successfully");
       }
    });
    this.getAllContacts();
  }

}
