import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddContactsComponent } from './add-contacts/add-contacts.component';
import { AppComponent } from './app.component';
import { DeletecontactComponent } from './deletecontact/deletecontact.component';
import { GetcontactComponent } from './getcontact/getcontact.component';
import { UpdateContactsComponent } from './update-contacts/update-contacts.component';
import { ViewAllContactsComponent } from './view-all-contacts/view-all-contacts.component';


const routes: Routes = [
 {path:"addcontacts", component:AddContactsComponent},
 {path:"update", component:UpdateContactsComponent},
 {path:"allcontacts", component:ViewAllContactsComponent},
 {path:"getcontact", component:GetcontactComponent},
 {path:"deletecontact", component:DeletecontactComponent},
 {path:"updatecontact" , component:UpdateContactsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
